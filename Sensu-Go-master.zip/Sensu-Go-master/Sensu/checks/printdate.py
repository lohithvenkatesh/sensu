from datetime import date

d0 = date(2008, 8, 18)
d1 = date(2008, 7, 26)
delta = d1 - d0
print(delta.days)
